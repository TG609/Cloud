
#include <stdio.h>

#include <conio.h>

#include <stdlib.h>
int main ()

{

int numero=0;

system("cls");

printf("\n\n Introduce un numero entero: ");

scanf("%d",&numero);

printf("\n El numero introducido es: %d", numero); getch();

}
