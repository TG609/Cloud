#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

main ()
{
	
int numero;

system("cls");
printf("\n\nIntroduce un numero: ");
scanf("%d",&numero);
if (numero%2==0)
{
	printf("%d es par", numero);
}


else {
	printf("%d es par", numero);
}

getch();
}
 
