

#include <stdio.h>

#include <conio.h>

#include <string.h>

#include <stdlib.h>

 main(void)

{

int nace, actual;

char nombre[35];
system("cls");

printf("\n\n Introduce tu nombre: ");

scanf("%s",&nombre);

printf(" Introduce tu a�o de nacimiento: ");

scanf("%d",&nace);

printf(" Introduce el a�o actual: "); scanf("%d",&actual);

printf("\n %s, Tienes %d a�os", strupr(nombre),(actual-nace)); getch();


}
