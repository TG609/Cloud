#include <stdio.h> /* la funci�n main inicia la ejecuci�n del programa */
int main (void)
{
	printf("Bienvenido a C!\n");
	return 0; /* indica que el programa termin� con exito */
} /* Fin de la funcion main */


