/* PRactica 4 */
/* Gabriel Pro 222 */
#include <stdio.h>
/* Para utilizar: printf(), getchar() */
main ()
{
	int numero1, numero2;
	int suma,resta,multiplicacion,division,modulo;
}
